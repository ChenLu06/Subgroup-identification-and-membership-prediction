# Reproducibility Package for: [Subgroup identification and membership prediction]

## Corresponding Author
- Name: [Luchen]
- Email: [chenlu.u@foxmail.com]

## Description
This archive contains code and data to reproduce the results and figures from the manuscript "[Subgroup identification and membership prediction]" submitted to [Biometrics].


## Contents
-**'Simulation/'**: which is the python code for the proposed  method with simulation.
	-'Case 1/','Case 2/','Case 3/','Case 4/','Case 5/','Case 6/','Case 7/','Case 8/','Case 9/','running time/'.
-**'Real Data/'**: Real data analysis module.
-**'Compare/'**: Method comparison results.
- `panitumumab_data.csv`: A  dataset used for demonstration.
- `README.txt`: This file.


## System Requirements
- **Software:**  Python 3.10.18 .
- **Dependencies:** The code requires the following packages:
	- Python: `numpy` (v1.24.3), `pandas` (v1.5.3), `matplotlib` (v3.7.1), `scipy` (v1.10.1), `seaborn` (v0.12.2), `scikit-learn` (v1.2.2), `statsmodels` (v0.14.0)
	- (To install them in Python, run: `pip install numpy==1.24.3 pandas==1.5.3 matplotlib==3.7.1 scipy==1.10.1 seaborn==0.12.2 scikit-learn==1.2.2 statsmodels==0.14.0`)
  

## Instructions to Run
1. Extract all files from the ZIP archive into a single folder.
2. Ensure Jupyter Notebook or Jupyter Lab is installed. You can install it via pip using the following command:
'''bash
pip install jupyterlab
'''
3.Open a terminal (or command prompt) and navigate to the folder from Step 1.
4. Start the Jupyter service:
'''bash
jupyter notebook
'''
5.Your default web browser will automatically open the Jupyter interface. Double-click to open the" DGP1.1 Covariate threshold model with n = 400.ipynb" file (Take the "Case 1" folder as an example; other simulations follow a similar procedure).
6.In the opened Notebook, sequentially select and run each code cell.
7.The Notebook will perform the following steps:
	--Generate simulated training and test datasets

	--Perform fused penalization estimation

	--Calculate accuracy metrics and Rand Indices

	--Save result plots and data to the results/ directory
